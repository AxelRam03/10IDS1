<template>
    <Clientes />
</template>

<script setup>
import Clientes from '@/components/home/Clientes.vue';
</script>
