<template>
    <Polizas />
</template>

<script  setup>
import Polizas from '@/components/home/Polizas.vue';
</script>
