<template>
  <Login/>
</template>

<script setup>
import Login from '@/components/home/Facturas.vue';

  //
</script>
